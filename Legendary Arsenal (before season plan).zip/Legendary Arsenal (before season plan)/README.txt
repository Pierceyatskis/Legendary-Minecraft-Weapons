Legendary Arsenal as it was before the season plan (built 2026-10-30 23:40).

This is the same jar that is in the "Legendary" CurseForge instance's mods folder right now.
It has the legendaries, accessories, Fallen Champions and Kings, the podium crafting and the
old task-based classes (Apprentice / Journeyman / Master), but none of the season plan:
no Legend Sigils or Legend Forges, no Chronicle, no PvP rules, no class levels or talents.

To play it: put the .jar in a Fabric 26.3 instance's mods folder (with Fabric API),
and remove any other legendary-arsenal jar from that folder.
